Participants performed a pre-scan practice at home via qualtrics (I can share the trial info with you if you plan to do this) (and also did the Unusual Uses Task)
Participants also practice before entering the scanner 
And once in the scanner too

Participants also underwent post-scan behavioural testing via qualtrics, which involved reporting the link the had made and rating the strength of the link they had made, their confidence in their memory of the link, and how much they used semantic-episodic memory to form the link. 
They also did a standard semantic association task after completing the post-scan survey.

(I can send you stuff for any of the above if you need it!)

The task itself is included in this folder (scanner_task).

The fMRI data are modelled parametrically:

Uniquess - more unique responses positive direction, less unique, negative direction
w2v - less associated (more difficult) positive direction, highly associated negative direction (easier)
episodic - more episodic responses positive direction, more semantic negative direction. 



