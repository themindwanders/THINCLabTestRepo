"""
Created on Wed Feb  7 11:53:49 2018

This script presents the following events in the following order: 
ITI [+] --> [word1-word2] --> [link question ]--> [+] --> [chevron] --> [+] --> [chevron] --> [+] --> [chevron] --> [+] --> [chevron] --> [+] --> [+] 

1. presents GUI to collect participant info
2. creates output file for participant (no risk of overwriting because each
file is unique due to the timestamp)
3. presents instructions
4. presents stimuli and accept keypress

What you need to run the script
The home-directory will be specified as the one in which the py script lives.
In the same directory you must have the following folders:
    instructions (must contain: goodbye.txt, prcatice.jpg, welcome.txt)
    csvFiles (must contain: EXP.csv)
A folder called data_name of the experiment will be created and will store the log files

@author: kmkr500, xw1365
"""


import codecs
import csv
import errno
import os
import random
from random import shuffle
import sys
from collections import OrderedDict
from datetime import datetime
from psychopy import core, event, gui, visual
import math
import numpy as np

#%% constant variables
#Pre-specify timing informations
within_trial = 0.5
inter_trial = 8.5
item_duration = 4.5
link_duration = 1
chev_duration = .5
#ww_response_duration = 2
#chev_response_duration = 1
frame = 120
#each_inter_trial = 9
trial_duration = 13.5
total_num = 144
rest_duration = 30
rest_inter_num = 24
blank_duration = .1


# for testing
#total_num = 6
#rest_duration = 5
#rest_inter_num = 2

#%%

'''%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%'''
''' 1st step: DEFINE YOUR FUNCTIONS'''
'''-------------------------------------------------------------------------'''
###############################################################################


# 1. PRELIMINSARY ACTIONS (e.g. set directory, get participant data, input csv and output log file)

# Ensure that relative paths start from the same directory as this script
def setDir():
    _thisDir = os.path.dirname(os.path.abspath(__file__)).decode(sys.getfilesystemencoding())
    os.chdir(_thisDir)
    return _thisDir


# Get participant info
def info_gui(expName):
    expInfo = {}
    expInfo['expname'] = expName
    expInfo['expdate'] = datetime.now().strftime('%Y%m%d_%H%M')
    expInfo['participant number'] = ''
    expInfo['run'] = ['1','2','3'] 

    dlg = gui.DlgFromDict(expInfo, title = 'Input Data', fixed = ['expname', 'expdate'], order = ['expname', 'expdate', 'participant number'])
    
     # creates a file with a name that is absolute path + info collected from GUI
    filename = 'data_' + expName + os.sep + '%s_%s_%s_%s.csv' %(expInfo['participant number'], 
    expInfo['expname'], expInfo['expdate'][-4:], expInfo['run'])
    
    # creates folder to store data, if not already present in directory
    def make_sure_path_exists(path):
        try:
            os.makedirs(path)
        except OSError as exception:
            if exception.errno != errno.EEXIST:
                raise    
    make_sure_path_exists('data_' + expName) 
    if not dlg.OK:
        print ('User cancelled the experiment')
        core.quit()
    return expInfo, filename
    
# Open a csv file, read through from the first row 
def load_conditions_dict(conditionfile):
    '''
    load each row as a dictionary with the headers as the keys
    save the headers in its original order for data saving
    '''

    with codecs.open(conditionfile, 'r', encoding='utf8') as f:
        reader = csv.DictReader(f)
        trials = []

        for row in reader:
            trials.append(row)
        
        # save field names as a list in order
        fieldnames = reader.fieldnames

    return trials, fieldnames    
    
    
def write_csv(filename, list_headers, thisTrial):
    '''
    append the data of the current trial to the data file
    if the data file has not been created, this function will create one


    attributes

    filename: str
        the file name generated when capturing participant info

    list_headers: list
        the headers in a list, will pass on to function create_headers

    thisTrial: dict
        a dictionary storing the current trial
    '''
    def create_headers(list_headers):
        '''
        create ordered headers for the output data csv file
        '''

        headers = []

        for header in list_headers:
            headers.append((header, None))

        return OrderedDict(headers)
    
    def create_dir(directory):
        '''

        create a directory if it doesn't exist.

        '''
        if not os.path.exists(directory):
            os.makedirs(directory)


    full_path = os.path.abspath(filename)
    directory = os.path.dirname(full_path)
    create_dir(directory)
    fieldnames = create_headers(list_headers)

    if not os.path.isfile(full_path):
        # headers and the first entry
        with codecs.open(full_path, 'ab+', encoding='utf8') as f:
            dw = csv.DictWriter(f, fieldnames=fieldnames)
            dw.writeheader()
            dw.writerow(thisTrial)
    else:
        with codecs.open(full_path, 'ab+', encoding='utf8') as f:
            dw = csv.DictWriter(f, fieldnames=fieldnames)
            dw.writerow(thisTrial)    
    
#------------------------------------------------------------------------------
# 2. MORE FUNCTIONS (e.g set window for display, instructions and goodbye )

# Allow to stop the experiment at any time
def quitEXP(endExpNow):
    if endExpNow:
        print ('User Cancelled')
        core.quit()

# Open a window
def set_window(fullscr=False, gui=True, color=1):
    if fullscr:
        gui = False
    win = visual.Window(size=(1920, 1080), color=(-1,-1,-1), fullscr=fullscr, allowGUI=gui, winType='pyglet', monitor='testMonitor', units ='pix', screen=0)

    return win

def trigger_exp():
    trigger = visual.TextStim(win,text= 'Experiment starts soon', font=sans,
    pos=[-50,0], height=62, wrapWidth=1100, color='white', bold = True)
    trigger.draw()
    win.flip()
    
def ready():

    ready = visual.TextStim(win,text= 'Do not move head', font=sans,
    pos=[-50,0], height=62, wrapWidth=1100, color='white', bold = True)
    ready.draw()
    ready_onset = win.flip()
    return ready_onset


def Instruction():
    instruct_txt = open('./instructions/welcome.txt', 'r').read().split('#\n')
    
    # and then enumerate 
    for i, cur in enumerate(instruct_txt):
        instrTxt.setText(cur)
        instrTxt.draw()
        win.flip()
        event.waitKeys(keyList=['space'])   # wait for spacebar to show the next screen
    if event.getKeys(keyList = ['escape']):
        quitEXP(True) 

 
def endOfBlock():
    instruct_txt = open('./instructions/endBlock.txt', 'r').read().split('#\n')
    #instructions screen 
    for i, cur in enumerate(instruct_txt):
        instrTxt.setText(cur)
        instrTxt.draw()
        win.flip()
        event.waitKeys(keyList=['space'])
    if event.getKeys(keyList = ['escape']):
        quitEXP(True)          
        
def goodbye(): 
    instruct_txt = open('./instructions/goodbye.txt', 'r').read().split('#\n')
    
    for i, cur in enumerate(instruct_txt):
        instrTxt.setText(cur)
        instrTxt.draw()
        win.flip()
        event.waitKeys(keyList=['space'])
    if event.getKeys(keyList = ['escape']):
        quitEXP(True)
        

'''%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%'''
''' 2nd step: CALL SOME OF THE PRELIMINARY FUNCTIONS DISPLAY MODULES'''
'''------------------------------------------------------------------------'''

# Set directory
setDir()
 
expName = 'wordPairfMRI_formal_fixedChev'

# Present GUI that captures participant info
expInfo, filename = info_gui(expName)
run = expInfo['run']
csvFile='./csvFiles/psycho_wordPairs_run{:}.csv'.format(expInfo['run']) 


# Sets the font - use the first on this list, if not available use the second, etc
sans = ['Arial','Gill Sans MT', 'Helvetica','Verdana'] 

# Defines the main window by calling set_window function
win = set_window(fullscr=True, gui=True, color=1)
#Objects not used

endBlock = visual.TextStim(win, name='end block', text='Well done! You have completed a block. Take a break, the next block will start soon..', color='white', height=50,)
expSoon = visual.TextStim(win, name='exp soon', text='Please press SPACEBAR to start the experiment', color='white', bold = False, wrapWidth = 2000, height =40)
instrTxt = visual.TextStim(win,text='default text', font=sans, name='instruction', pos=[-50,0], height=32, wrapWidth=1100, color='white' )
fact = visual.TextStim(win, text='', font=sans, color='white', height=40, wrapWidth=1500, pos=(0,420))
next = visual.TextStim(win, text='PRESS SPACEBAR', font=sans, color='white', height=20, wrapWidth=1500, pos=(0,-400))
tasktype = visual.ImageStim(win, image=None, pos=(-400,150), size= (150,150))

# Define objects

word_1 = visual.TextStim(win, text='', font=sans, color='white', height=62, bold = True, wrapWidth=1500, pos=(-300,0))
word_2 = visual.TextStim(win, text='', font=sans, color='white', height=62, bold = True, wrapWidth=1500, pos=(300,0))
link_made = visual.TextStim(win, text='', font=sans, color='white', height=62, bold = True, wrapWidth=1500, pos=(0,25))
chev1 = visual.TextStim(win, text='', font=sans, color='white', height=62, wrapWidth=1500, pos=(0,0))   
chev2 = visual.TextStim(win, text='', font=sans, color='white', height=62, wrapWidth=1500, pos=(0,0)) 
chev3 = visual.TextStim(win, text='', font=sans, color='white', height=62, wrapWidth=1500, pos=(0,0))   
chev4 = visual.TextStim(win, text='', font=sans, color='white', height=62, wrapWidth=1500, pos=(0,0)) 
chev5 = visual.TextStim(win, text='', font=sans, color='white', height=62, wrapWidth=1500, pos=(0,0))   
chev6 = visual.TextStim(win, text='', font=sans, color='white', height=62, wrapWidth=1500, pos=(0,0)) 
chev7 = visual.TextStim(win, text='', font=sans, color='white', height=62, wrapWidth=1500, pos=(0,0))   
chev8 = visual.TextStim(win, text='', font=sans, color='white', height=62, wrapWidth=1500, pos=(0,0)) 
chev9 = visual.TextStim(win, text='', font=sans, color='white', height=62, wrapWidth=1500, pos=(0,0))   
chev10 = visual.TextStim(win, text='', font=sans, color='white', height=62, wrapWidth=1500, pos=(0,0)) 
#FeedBack  =  visual.TextStim(win, text='Response detected!', font=sans, color='grey', height=62, pos=(0,50))
ww_link_fixation = visual.TextStim(win, name = 'fixation', text = '+', color = 'white', height = 62, bold = True)
#link_ch1_fixation = visual.TextStim(win, name = 'fixation', text = '+', color = 'white', height = 62, bold = True)
ch_blank1 = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
ch_blank2 = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
ch_blank3 = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
ch_blank4 = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
ch_blank5 = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
ch_blank6 = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
ch_blank7 = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
ch_blank8 = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
ch_blank9 = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
ch_blank10 = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
#ch_blank = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
#ch_blank = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
#ch_blank = visual.TextStim(win, name = 'blankscr', text = '+', color = 'black', height = 62, bold = True)
#ch2_ch3_fixation = visual.TextStim(win, name = 'fixation', text = '+', color = 'white', height = 62, bold = True)
#ch3_ch4_fixation = visual.TextStim(win, name = 'fixation', text = '+', color = 'white', height = 62, bold = True)
fixation_red = visual.TextStim(win, name = 'fixation_red', text = '+', color = 'white', height = 62, bold = True)
fixation_orange = visual.TextStim(win, name = 'fixation_orange', text = '+', color = 'white', height = 62, bold = True)
fixation_green = visual.TextStim(win, name = 'fixationgreen', text = '+', color = 'white', height = 62, bold = True) 


'''%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%'''
''' 3rd step: RUN EXPERIMENT'''
'''------------------------------------------------------------------------'''



# sets a local clock that will be used to store timing information synced with the scanner
expClock = core.Clock()
expClock.reset()   

  
# the csv file we want to load into the function is named at the top of the script
def runEXP(csvFile):
    
    all_trials, headers = load_conditions_dict(conditionfile=csvFile) # use the load_condition_dict to load all trials in the csv    
    headers += ['ExpDate','Subject','TrialOrder','ww_duration','ww_RT','KeyPress_ww','link_strength','linkRT','linkduration',
    'chev1_accuracy','ch1_RT','KeyPress_chev1','chev2_accurarcy','ch2_RT', 'KeyPress_chev2','chev3_accurarcy','ch3_RT', 
    'KeyPress_chev3','chev4_accurarcy','ch4_RT', 'KeyPress_chev4','chev5_accuracy','ch5_RT','KeyPress_chev5','chev6_accurarcy',
    'ch6_RT', 'KeyPress_chev6','chev7_accurarcy','ch7_RT','KeyPress_chev7','chev8_accurarcy','ch8_RT', 'KeyPress_chev8',
    'chev9_accuracy','ch9_RT','KeyPress_chev9','chev10_accurarcy','ch10_RT', 'KeyPress_chev10','ITI_duration','ITI_green_onset','ww_onset',
    'ww_link_fix_onset','linkOnset','ch_blank1_onset','ch1_onset','ch_blank2_onset','ch2_onset','ch_blank3_onset','ch3_onset', 'ch_blank4_onset',
    'ch4_onset', 'ch_blank5_onset','ch5_onset','ch_blank6_onset','ch6_onset','ch_blank7_onset','ch7_onset','ch_blank8_onset','ch8_onset',
    'ch_blank9_onset','ch9_onset','ch_blank10_onset','ch10_onset','ITI_red_onset','ITI_orange_onset','rest_onset','rest_message']# and adds new headers to our log file (that are not in the design file) 
    endExpNow = False # handle: escape experiment
    
    
    # a loop that cycles through the trials
    trial_num = 1         # initialize a counter 

    trigger_exp()# Trigger the scanner, displays that experiment is about to start -               
    event.waitKeys(keyList=['5'], timeStamped=True)# waiting for dummy volumes to be acquired, experimenter have to press 5. The scanner would be triggered in this way.# Not useful for the behaviour experiment
    run_onset = win.flip() #ready()# this is to discard volumes at the beginning of the scanning. 
    #core.wait(7.5)  # 5 TRs ~ check with Andre. Zhyiao found that for Multi-echo with Siemens it is advisable to discard the first 5 TRs.. 
    
    rest_num = 0
    
    for trial in all_trials:
        
        
        
        print("this is trial number %s" %trial['TrialNum'])    

                         
        # Here content is assigned to stimuli   
        word_1.setText(trial['word1'])
        word_2.setText(trial['word2'])
        link_made.setText('            strength?\n\n\nlow        .       .        high\n')
        chev1.setText(trial['chevText'])
        chev2.setText(trial['chevText2'])
        chev3.setText(trial['chevText3'])
        chev4.setText(trial['chevText4'])
        chev5.setText(trial['chevText5'])
        chev6.setText(trial['chevText6'])
        chev7.setText(trial['chevText7'])
        chev8.setText(trial['chevText8'])
        chev9.setText(trial['chevText9'])
        chev10.setText(trial['chevText10'])
        
       #display fixation cross and print duration of presentation
        timetodraw = run_onset + 1 + (trial_num - 1) * trial_duration + (rest_num ) * rest_duration 
        
        fixation_green.draw()
          
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass

        withintrial_green_onset = win.flip()       

        
       #display word pair on screen
        word_1.draw()
        word_2.draw()
        
        timetodraw = withintrial_green_onset + within_trial
        
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass
        ww_onset = win.flip() 
        word_1.keys = event.waitKeys(keyList=['0','1','2','3','4','6','7','8','9','escape'], timeStamped=True, maxWait=item_duration)   # accept keypress and store time (used to calculate RT)
        
        if word_1.keys is not None:
            if word_1.keys[0][0]=='escape':            # escape experiment if esc is pressed
                endExpNow = True
                if endExpNow:
                    print ('User Cancelled')
                    core.quit()
            else:
               wordpair_RT = word_1.keys[0][1] - ww_onset # time of pressing the keys - time of flipping the window  
               ww_keypress= word_1.keys[0][0]
#               core.wait(item_duration-wordpair_RT)                
              
        else:
            ww_keypress = 'None'                   # if no key is pressed store 'none'
            wordpair_RT = item_duration
          
                      
        #display ww - link fixation cross and print duration of presentation
        ww_link_fixation.draw()                
        timetodraw = withintrial_green_onset + within_trial+ item_duration 
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        withintrial_wwlink_onset = win.flip()
        
        # now display linkquery response trial                
        link_made.draw()
        event.clearEvents()  
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        link_onset = win.flip() 
        link_made.keys = event.waitKeys(keyList=['0','1','2','3','4','6','7','8','9','escape'], timeStamped=True, maxWait=link_duration)   # accept keypress and store time (used to calculate RT)
        
        if link_made.keys is not None:
            if link_made.keys[0][0]=='escape':            # escape experiment if esc is pressed
                endExpNow = True
                if endExpNow:
                    print ('User Cancelled')
                    core.quit()
            else:
               link_made_RT = link_made.keys[0][1] - link_onset # time of pressing the keys - time of flipping the window  
               link_keypress= link_made.keys[0][0]               
                           
        else:
            link_keypress = 'None'                   # if no key is pressed store 'none'
            link_made_RT = link_duration
            correct = 0 
        
        #display blank between link and first chev and print duration of presentation
        ch_blank1.draw()                
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        ch_blank1_onset = win.flip()
        
        
        # now display chev 1 response trial                
        chev1.draw()
        event.clearEvents()  
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + blank_duration
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        chev1_onset = win.flip() 
        chev1.keys = event.waitKeys(keyList=['0','1','2','3','4','6','7','8','9','escape'], timeStamped=True, maxWait=chev_duration)   # accept keypress and store time (used to calculate RT)
        
        if chev1.keys is not None:
            if chev1.keys[0][0]=='escape':            # escape experiment if esc is pressed
                endExpNow = True
                if endExpNow:
                    print ('User Cancelled')
                    core.quit()
            else:
               chev1_RT = chev1.keys[0][1] - chev1_onset # time of pressing the keys - time of flipping the window  
               c1_keypress= chev1.keys[0][0]              
               if c1_keypress == trial['chev1_corresp']:
                    chev1.correct = 1
               else:
                    chev1.correct = 0
                       
        else:
            c1_keypress = 'None'                   # if no key is pressed store 'none'
            chev1_RT = chev_duration
            chev1.correct = 0 
        
           
                        
        #display between chev blank screen and print duration of presentation
        ch_blank2.draw()                
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + chev_duration + blank_duration
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        ch_blank2_onset = win.flip()
        
        
        # now display chev2 response trial                
        chev2.draw()
        event.clearEvents()  
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + chev_duration + (blank_duration * 2)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        chev2_onset = win.flip() 
        chev2.keys = event.waitKeys(keyList=['0','1','2','3','4','6','7','8','9','escape'], timeStamped=True, maxWait=chev_duration)   # accept keypress and store time (used to calculate RT)
        

        if chev2.keys is not None:
            if chev2.keys[0][0]=='escape':            # escape experiment if esc is pressed
                endExpNow = True
                if endExpNow:
                    print ('User Cancelled')
                    core.quit()
            else:
               chev2_RT = chev2.keys[0][1] - chev2_onset # time of pressing the keys - time of flipping the window  
               c2_keypress= chev2.keys[0][0]               
               if c2_keypress == trial ['chev2_corresp']:
                    chev2.correct = 1
               else:
                    chev2.correct = 0
                      
        else:
            c2_keypress = 'None'                   # if no key is pressed store 'none'
            chev2_RT = chev_duration
            chev2.correct = 0 

        #display chev blank screen and print duration of presentation
        ch_blank3.draw()                
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 2) + (blank_duration * 2)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        ch_blank3_onset = win.flip()
        
            
        # now display chev 3 response trial                
        chev3.draw()
        event.clearEvents()  
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 2) + (blank_duration * 3)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        chev3_onset = win.flip() 
        chev3.keys = event.waitKeys(keyList=['0','1','2','3','4','6','7','8','9','escape'], timeStamped=True, maxWait=chev_duration)   # accept keypress and store time (used to calculate RT)
        
        if chev3.keys is not None:
            if chev3.keys[0][0]=='escape':            # escape experiment if esc is pressed
                endExpNow = True
                if endExpNow:
                    print ('User Cancelled')
                    core.quit()
            else:
               chev3_RT = chev3.keys[0][1] - chev3_onset # time of pressing the keys - time of flipping the window  
               c3_keypress= chev3.keys[0][0]               
               if c3_keypress == trial ['chev3_corresp']:
                    chev3.correct = 1
               else:
                    chev3.correct = 0
                       
        else:
            c3_keypress = 'None'                   # if no key is pressed store 'none'
            chev3_RT = chev_duration
            chev3.correct = 0 
        
        #display link - chev fixation cross and print duration of presentation
        ch_blank4.draw()                
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 3) + (blank_duration * 3)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        ch_blank4_onset = win.flip()
        
            
        # now display chev4 response trial                
        chev4.draw()
        event.clearEvents()  
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 3) + (blank_duration * 4)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        chev4_onset = win.flip() 
        chev4.keys = event.waitKeys(keyList=['0','1','2','3','4','6','7','8','9','escape'], timeStamped=True, maxWait=chev_duration)   # accept keypress and store time (used to calculate RT)
        
        if chev4.keys is not None:
            if chev4.keys[0][0]=='escape':            # escape experiment if esc is pressed
                endExpNow = True
                if endExpNow:
                    print ('User Cancelled')
                    core.quit()
            else:
               chev4_RT = chev4.keys[0][1] - chev4_onset # time of pressing the keys - time of flipping the window  
               c4_keypress= chev4.keys[0][0]              
               if c4_keypress == trial ['chev4_corresp']:
                    chev4.correct = 1
               else:
                    chev4.correct = 0
           
        else:
            c4_keypress = 'None'                   # if no key is pressed store 'none'
            chev4_RT = chev_duration
            chev4.correct = 0 
            
        #display blank screen and print duration of presentation
        ch_blank5.draw()                
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 4) + (blank_duration * 4)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        ch_blank5_onset = win.flip()
        

        # now display chev 5 response trial                
        chev5.draw()
        event.clearEvents()  
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 4) + (blank_duration * 5)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        chev5_onset = win.flip() 
        chev5.keys = event.waitKeys(keyList=['0','1','2','3','4','6','7','8','9','escape'], timeStamped=True, maxWait=chev_duration)   # accept keypress and store time (used to calculate RT)
        
        if chev5.keys is not None:
            if chev5.keys[0][0]=='escape':            # escape experiment if esc is pressed
                endExpNow = True
                if endExpNow:
                    print ('User Cancelled')
                    core.quit()
            else:
               chev5_RT = chev5.keys[0][1] - chev5_onset # time of pressing the keys - time of flipping the window  
               c5_keypress= chev5.keys[0][0]              
               if c5_keypress == trial['chev5_corresp']:
                    chev5.correct = 1
               else:
                    chev5.correct = 0
                       
        else:
            c5_keypress = 'None'                   # if no key is pressed store 'none'
            chev5_RT = chev_duration
            chev5.correct = 0 
        
           
        
        #display blank screen and print duration of presentation
        ch_blank6.draw()                
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 5) + (blank_duration * 5)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        ch_blank6_onset = win.flip()
        
        # now display chev6 response trial                
        chev6.draw()
        event.clearEvents()  
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 5) + (blank_duration * 6)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        chev6_onset = win.flip() 
        chev6.keys = event.waitKeys(keyList=['0','1','2','3','4','6','7','8','9','escape'], timeStamped=True, maxWait=chev_duration)   # accept keypress and store time (used to calculate RT)
        

        if chev6.keys is not None:
            if chev6.keys[0][0]=='escape':            # escape experiment if esc is pressed
                endExpNow = True
                if endExpNow:
                    print ('User Cancelled')
                    core.quit()
            else:
               chev6_RT = chev6.keys[0][1] - chev6_onset # time of pressing the keys - time of flipping the window  
               c6_keypress= chev6.keys[0][0]               
               if c6_keypress == trial ['chev6_corresp']:
                    chev6.correct = 1
               else:
                    chev6.correct = 0
                      
        else:
            c6_keypress = 'None'                   # if no key is pressed store 'none'
            chev6_RT = chev_duration
            chev6.correct = 0 

        
        
        #display blank screen and print duration of presentation
        ch_blank7.draw()                
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 6) + (blank_duration * 6)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        ch_blank7_onset = win.flip()
        
        # now display chev 7 response trial                
        chev7.draw()
        event.clearEvents()  
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 6) + (blank_duration * 7)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        chev7_onset = win.flip() 
        chev7.keys = event.waitKeys(keyList=['0','1','2','3','4','6','7','8','9','escape'], timeStamped=True, maxWait=chev_duration)   # accept keypress and store time (used to calculate RT)
        
        if chev7.keys is not None:
            if chev7.keys[0][0]=='escape':            # escape experiment if esc is pressed
                endExpNow = True
                if endExpNow:
                    print ('User Cancelled')
                    core.quit()
            else:
               chev7_RT = chev7.keys[0][1] - chev7_onset # time of pressing the keys - time of flipping the window  
               c7_keypress= chev7.keys[0][0]               
               if c7_keypress == trial ['chev3_corresp']:
                    chev7.correct = 1
               else:
                    chev7.correct = 0
                       
        else:
            c7_keypress = 'None'                   # if no key is pressed store 'none'
            chev7_RT = chev_duration
            chev7.correct = 0 
        
        #display blank screen and print duration of presentation
        ch_blank8.draw()                
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 7) + (blank_duration * 7)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        ch_blank8_onset = win.flip()
            
            
        # now display chev8 response trial                
        chev8.draw()
        event.clearEvents()  
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 7) + (blank_duration * 8)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        chev8_onset = win.flip() 
        chev8.keys = event.waitKeys(keyList=['0','1','2','3','4','6','7','8','9','escape'], timeStamped=True, maxWait=chev_duration)   # accept keypress and store time (used to calculate RT)
        
        if chev8.keys is not None:
            if chev8.keys[0][0]=='escape':            # escape experiment if esc is pressed
                endExpNow = True
                if endExpNow:
                    print ('User Cancelled')
                    core.quit()
            else:
               chev8_RT = chev8.keys[0][1] - chev8_onset # time of pressing the keys - time of flipping the window  
               c8_keypress= chev8.keys[0][0]              
               if c8_keypress == trial ['chev8_corresp']:
                    chev8.correct = 1
               else:
                    chev8.correct = 0
           
        else:
            c8_keypress = 'None'                   # if no key is pressed store 'none'
            chev8_RT = chev_duration
            chev8.correct = 0 
            
         #display blank screen and print duration of presentation
        ch_blank9.draw()                
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 8) + (blank_duration * 8)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        ch_blank9_onset = win.flip()
            
        # now display chev 9 response trial                
        chev9.draw()
        event.clearEvents()  
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 8) + (blank_duration * 9)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        chev9_onset = win.flip() 
        chev9.keys = event.waitKeys(keyList=['0','1','2','3','4','6','7','8','9','escape'], timeStamped=True, maxWait=chev_duration)   # accept keypress and store time (used to calculate RT)
        
        if chev9.keys is not None:
            if chev9.keys[0][0]=='escape':            # escape experiment if esc is pressed
                endExpNow = True
                if endExpNow:
                    print ('User Cancelled')
                    core.quit()
            else:
               chev9_RT = chev9.keys[0][1] - chev9_onset # time of pressing the keys - time of flipping the window  
               c9_keypress= chev9.keys[0][0]               
               if c9_keypress == trial ['chev9_corresp']:
                    chev9.correct = 1
               else:
                    chev9.correct = 0
                       
        else:
            c9_keypress = 'None'                   # if no key is pressed store 'none'
            chev9_RT = chev_duration
            chev9.correct = 0 
        
         #display blank screen and print duration of presentation
        ch_blank10.draw()                
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 9) + (blank_duration * 9)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        ch_blank10_onset = win.flip()
            
        # now display chev10 response trial                
        chev10.draw()
        event.clearEvents()  
        timetodraw = withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 9) + (blank_duration * 10)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        chev10_onset = win.flip() 
        chev10.keys = event.waitKeys(keyList=['0','1','2','3','4','6','7','8','9','escape'], timeStamped=True, maxWait=chev_duration)   # accept keypress and store time (used to calculate RT)
        
        if chev10.keys is not None:
            if chev10.keys[0][0]=='escape':            # escape experiment if esc is pressed
                endExpNow = True
                if endExpNow:
                    print ('User Cancelled')
                    core.quit()
            else:
               chev10_RT = chev10.keys[0][1] - chev10_onset # time of pressing the keys - time of flipping the window  
               c10_keypress= chev10.keys[0][0]              
               if c10_keypress == trial ['chev10_corresp']:
                    chev10.correct = 1
               else:
                    chev10.correct = 0
           
        else:
            c10_keypress = 'None'                   # if no key is pressed store 'none'
            chev10_RT = chev_duration
            chev10.correct = 0 
            

        #display end trial fixation crosses and print duration of presentation
        fixation_red.draw()                
        timetodraw =  withintrial_green_onset + within_trial + item_duration + within_trial + link_duration + (chev_duration * 10) + (blank_duration * 10)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass   
        withintrial_red_onset = win.flip() 
               
        fixation_orange.draw()
        timetodraw = withintrial_green_onset + within_trial + item_duration + (within_trial * 2) + link_duration + (chev_duration * 10) + (blank_duration * 10)
        while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
            pass  
        withintrial_orange_onset = win.flip()        
        
        
        
        # the followig lines store in 'trials' all the info that we want to include in output file     
        trial['TrialOrder'] = trial_num
        trial['Subject'] = expInfo['participant number']
        trial['ExpDate'] = expInfo ['expdate']
        trial['ww_link_fix_onset'] = withintrial_wwlink_onset - run_onset
        #trial['link_ch1_fix_onset'] = withintrial_linkch_onset - run_onset
        #trial['ch1_ch2_fix_onset'] = withintrial_ch1ch2_onset - run_onset
        #trial['ch2_ch3_fix_onset'] = withintrial_ch2ch3_onset - run_onset
        #trial['ch3_ch4_fix_onset'] = withintrial_ch3ch4_onset - run_onset
        trial['ch_blank1_onset'] = ch_blank1_onset - run_onset
        trial['ch_blank2_onset'] = ch_blank2_onset - run_onset
        trial['ch_blank3_onset'] = ch_blank3_onset - run_onset
        trial['ch_blank4_onset'] = ch_blank4_onset - run_onset
        trial['ch_blank5_onset'] = ch_blank5_onset - run_onset
        trial['ch_blank6_onset'] = ch_blank6_onset - run_onset
        trial['ch_blank7_onset'] = ch_blank7_onset - run_onset
        trial['ch_blank8_onset'] = ch_blank8_onset - run_onset
        trial['ch_blank9_onset'] = ch_blank9_onset - run_onset
        trial['ch_blank10_onset'] = ch_blank10_onset - run_onset
        trial['ITI_red_onset'] = withintrial_red_onset - run_onset
        trial['ITI_orange_onset'] = withintrial_orange_onset - run_onset
        trial['ITI_green_onset'] = withintrial_green_onset - run_onset
        trial['ITI_duration'] = within_trial
        trial['ww_onset'] = ww_onset - run_onset
        trial['ww_duration'] = item_duration
        trial['linkRT'] = link_made_RT
        trial['linkOnset'] = link_onset - run_onset
        trial['linkduration'] = link_duration
        #trial['link_strength'] = link_made
        trial['ch1_onset'] =  chev1_onset - run_onset
        trial['ch2_onset'] =  chev2_onset - run_onset
        trial['ch3_onset'] =  chev3_onset - run_onset
        trial['ch4_onset'] =  chev4_onset - run_onset
        trial['ch5_onset'] =  chev5_onset - run_onset
        trial['ch6_onset'] =  chev6_onset - run_onset
        trial['ch7_onset'] =  chev7_onset - run_onset
        trial['ch8_onset'] =  chev8_onset - run_onset
        trial['ch9_onset'] =  chev9_onset - run_onset
        trial['ch10_onset'] =  chev10_onset - run_onset
        #trial['ch11_onset'] =  chev3_onset - run_onset
        #trial['ch12_onset'] =  chev4_onset - run_onset
        trial['ww_RT'] = wordpair_RT
        trial['ch1_RT'] = chev1_RT
        trial['ch2_RT'] = chev2_RT
        trial['ch3_RT'] = chev3_RT
        trial['ch4_RT'] = chev4_RT
        trial['ch5_RT'] = chev5_RT
        trial['ch6_RT'] = chev6_RT
        trial['ch7_RT'] = chev7_RT
        trial['ch8_RT'] = chev8_RT
        trial['ch9_RT'] = chev9_RT
        trial['ch10_RT'] = chev10_RT
        #trial['ch11_RT'] = chev3_RT
        #trial['ch12_RT'] = chev4_RT
        # trial['Response_duration'] = response_duration
        trial['KeyPress_ww'] = ww_keypress
        trial['link_strength'] = link_keypress
        trial['KeyPress_chev1'] = c1_keypress
        trial['KeyPress_chev2'] = c2_keypress
        trial['KeyPress_chev3'] = c3_keypress
        trial['KeyPress_chev4'] = c4_keypress
        trial['KeyPress_chev5'] = c5_keypress
        trial['KeyPress_chev6'] = c6_keypress
        trial['KeyPress_chev7'] = c7_keypress
        trial['KeyPress_chev8'] = c8_keypress
        trial['KeyPress_chev9'] = c9_keypress
        trial['KeyPress_chev10'] = c10_keypress
        #trial['KeyPress_chev11'] = c3_keypress
        #trial['KeyPress_chev12'] = c4_keypress
       # trial['Accuracy'] = correct
        trial['chev1_accuracy']= chev1.correct
        trial['chev2_accurarcy']= chev2.correct
        trial['chev3_accurarcy']= chev3.correct
        trial['chev4_accurarcy']= chev4.correct
        trial['chev5_accuracy']= chev5.correct
        trial['chev6_accurarcy']= chev6.correct
        trial['chev7_accurarcy']= chev7.correct
        trial['chev8_accurarcy']= chev8.correct
        trial['chev9_accuracy']= chev9.correct
        trial['chev10_accurarcy']= chev10.correct
        #trial['chev11_accurarcy']= chev3.correct
        #trial['chev12_accurarcy']= chev4.correct
        
            # calls the function that writes csv output
        
        # to decide whether the participants need to have a rest
        # rest 30s for each 24 trials
        
        
        if int (trial['TrialNum']) % rest_inter_num ==0:
            
#            percentage = total_num/int(trial['TrialNum'])
             
            rest_message = '1/2 of this block done!'

            rest = visual.TextStim(win, text = rest_message, color = 'white', height = 62, bold = True)
            
            rest.draw()
                
            timetodraw =  run_onset + 1.5 + (trial_num ) * trial_duration 
            
            while core.monotonicClock.getTime() < (timetodraw - (1/frame)):
                pass 
                
            rest_onset = win.flip()  
            
            rest_num +=1
            
        else:
            rest_onset ='None'
            rest_message = 'None'
            
        trial['rest_onset']= rest_onset
        trial['rest_message']=rest_message
        
        write_csv(filename, headers, trial) 
    
        # this counter keeps track of the number of iteration (which is also the trial number)
        trial_num +=1
        
        
            
expClock = core.Clock()# sets a local clock that will be used to store timing information RELATIVE TO the scanner
expClock.reset()

runEXP(csvFile) # Now that the dummy volumes have been acquired start the task

# calls function that displays goodbye txt file and quits
endOfBlock()
win.close()
core.quit()
